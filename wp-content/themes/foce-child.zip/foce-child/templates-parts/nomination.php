<section class="sectionNomination">
        <h4><span class="fade-in">Fleurs d’oranger & chats errants<br /> est nominé aux Oscars Short<br /> Film
                        Animated de 2022 !</span><span class="animationTitre1"></span></h4>
        <img class="logo-oscars" src="<?php echo get_stylesheet_directory_uri() . '/assets/images/oscars.png' ?>"
                alt="logo nomination oscars">
</section>