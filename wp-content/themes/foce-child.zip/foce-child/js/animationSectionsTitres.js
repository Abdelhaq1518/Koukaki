// Fonction pour observer et rendre visibles les éléments au scroll
function observeAndShowElements() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      } else {
        entry.target.classList.remove("visible");
      }
    });
  });

  const elementsToObserve = document.querySelectorAll('.fade-in, h2, h3, h4');

  elementsToObserve.forEach(element => {
    observer.observe(element);
  });
}

// Fonction pour observer et afficher les éléments à chaque fois que la page est redimensionnée ou défilée
function observeElementsOnScroll() {
  observeAndShowElements();
}

// Appeler la fonction pour observer et afficher les éléments une fois que la page est chargée
window.addEventListener('DOMContentLoaded', observeAndShowElements);

// Réactiver l'observation des éléments à chaque fois que la fenêtre est redimensionnée ou que la page est défilée
window.addEventListener('resize', observeElementsOnScroll);
window.addEventListener('scroll', observeElementsOnScroll);

console.log("Le script JavaScript animationSectionsTitres.js est chargé.");
